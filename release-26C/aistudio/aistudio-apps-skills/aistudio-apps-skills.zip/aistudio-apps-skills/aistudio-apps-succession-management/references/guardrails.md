# Guardrails

## Existing artifacts

Existing artifacts discovered locally or through the environment are read/reuse only. They may be:

- discovered
- inspected
- summarized
- referenced
- reused as dependencies

They must not be:

- modified
- renamed
- deleted
- overwritten
- re-scaffolded
- recreated in place
- patched
- saved over
- force-fetched over local changes

If the user asks to modify an existing artifact, redirect to a safe alternative: create or revise a new current-flow artifact that references the existing artifact.

## Current-flow artifacts

Only artifacts created during the current succession-management app flow may be modified. Current-flow artifacts may include newly created apps, workspaces, summary-section configuration, panels, workflows, tools, actions, agents, and implementation drafts created specifically for this app.

Before modifying any artifact, verify that it was created in the current guided flow. If provenance is unclear, treat the artifact as existing and read/reuse only.

## Local-first discovery

Search the local workspace or local AI Studio project before searching the environment. Environment discovery is allowed only when no related local artifact is found, or when the user explicitly asks to compare local results with environment artifacts.

Environment discovery must be read-only. Do not fetch over local files, save, publish, force refresh, overwrite, or otherwise change local or server artifacts as part of discovery. If `aistudio` requires explicit confirmation before environment or server lookup, pause and ask for confirmation.

Apply local-first discovery to workflow discovery, app/workspace discovery, business-object discovery, supporting-artifact discovery, and summary-section pattern lookup.

## Response safety and clarity

Keep responses medium length by default. Do not become terse, and do not overload beginners with long explanations. Do not summarize unnecessarily. Use summaries only when they help orientation, when returning from `aistudio`, when validating, or when closing a stage.

When extra detail is useful but not required, include `Elaborate` as an option before `Stop`. Avoid forced brief/detail prompt patterns.

Do not use first-person pronouns in user-facing responses generated under this skill.

## File creation confirmation

Before creating any new file, present the planned creation operation and obtain explicit user confirmation. This applies to AI Studio app files, workflow files, panel/app updates, summary-section configuration, supporting artifacts, generated specs saved as files, and any other local file write.

Do not create files in the same response that first introduces a pre-build checkpoint. The checkpoint must be reviewed first.

## Summary-section rules

MVP must populate the existing app summary section. Do not create a separate Summary panel by default.

Use this order:

1. Search related local apps for summary-section patterns through `aistudio`.
2. If no related local reference is found, search environment apps read-only through `aistudio`.
3. Use discovered apps as references only. Do not modify them.
4. If no usable summary pattern is discovered, apply the fallback only to the current-flow MVP app: set `include in summary` on the three parent MVP workflow panels.

Fallback parent panels:

- Succession Overview
- Risk of Loss
- Impact of Loss

Do not include person-level drill-down panels in the parent app summary by fallback.

Do not invent summary-section schema fields beyond the confirmed `include in summary` property fallback. If `aistudio` discovers a different summary configuration method, use the discovered method for the current-flow app only after user confirmation.

## MVP action rules

The MVP must include basic interaction behavior where supported by discovered or created workflows:

- expand panels
- select employee row
- drill down to person-level details
- ask follow-up questions about displayed data where supported

Do not invent action payloads, widget behavior, or routing details. Use `aistudio` for implementation.

## Post-MVP continuation

After MVP creation and validation, do not stop with only a completion summary. Offer next choices for improvements, such as successor suggestion and candidate review, opt-in create-succession, communication, complete-app panels, additional workspace, summary review, validation, technical view, and stop.

If validation issues remain, recommend fixing validation first. Otherwise, successor suggestion and candidate review is usually the recommended next enhancement after MVP.

## `SP_` prefix

Use `SP_` for new succession-management artifact codes where `aistudio` conventions require artifact codes. Do not rename existing canonical artifacts or existing discovered artifacts just to add this prefix.

Canonical README workflow codes are discovery targets and may not use `SP_`. Treat them as existing-environment targets, not as new artifact-code requirements.

## Technical view control

Normal user-facing summaries should hide:

- workflow codes
- artifact file names
- internal identifiers
- business object codes
- agent codes
- tool codes
- widget payload details
- action payload details
- CLI commands

Offer technical view as an option after discovery, before implementation handoff, during validation, and whenever the user asks for implementation details.

## No invented implementation details

Do not invent:

- AI Studio commands
- CLI flags
- file paths
- app schema fields beyond confirmed requirements
- widget types
- action payloads
- workflow nodes
- business objects
- agents
- tools
- connector names
- server state
- validation results
- fit or gap assessments for existing artifacts
- summary-section implementation details beyond discovered patterns or the confirmed `include in summary` fallback

When an implementation contract is unclear, stop and ask or hand off to `aistudio` for discovery.

## Workflow mapping neutrality

For existing artifacts, do not show or infer fit, gap, suitability, readiness, coverage, or confidence. Show only discovered status, names, short descriptions, and user decisions.

Descriptions must come from the domain reference or `aistudio` discovery/inspection results. If unavailable, say that the description is unavailable from discovery.

## Side-effecting actions

Create succession, update records, send communications, save server state, fetch server state, publish, force fetch, and similar operations require explicit user intent. Treat confirm-and-create succession as opt-in, not part of the default MVP.

Before a side-effecting action is planned or built:

1. Label the action as side-effecting.
2. Confirm that the user wants it included.
3. Hand off to `aistudio` to confirm supported implementation paths.
4. Record inclusion or omission in the build brief.

## Base skill protection

Never modify the base `aistudio` skill. Do not edit, patch, overwrite, or repackage it as part of this companion skill's runtime flow.

## Response-length safety

Keep responses conversational and medium length. Do not become terse, but do not overwhelm the user with all available domain detail. Use `Elaborate` as a choice before `Stop` when additional details are useful but not required for the current decision.

## Validation checklist

Before finalizing a build brief, verify:

- explicit confirmation happened before each file creation
- existing discovered artifacts were not modified
- only current-flow artifacts were modified
- local workspace discovery happened before any environment discovery
- summary-section pattern lookup searched local apps before environment apps
- MVP summary section was populated
- if summary fallback was used, `include in summary` was set only on Succession Overview, Risk of Loss, and Impact of Loss parent workflow panels
- person-level drill-down panels were not added to the parent summary by fallback
- MVP included basic expand, row selection, drill-down, and supported follow-up-question behavior
- workflow reuse skipped granular workflow-internal decisions
- new workflow creation discovered business objects first
- workflow mapping avoided fit and gap language
- technical codes were hidden unless technical view was requested
- canonical discovery targets were used where relevant
- default scope was MVP plus person-level drill-down unless changed by the user
- successor suggestion was treated as optional
- create-succession behavior was opt-in
- communication was optional and explicitly selected before planning
- post-MVP improvement choices were offered after MVP completion
- all AI Studio operations were handed off to `aistudio`
- new artifact codes used `SP_` where applicable
