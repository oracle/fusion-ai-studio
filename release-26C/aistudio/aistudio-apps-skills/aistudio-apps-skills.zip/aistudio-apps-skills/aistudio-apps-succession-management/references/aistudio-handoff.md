# AI Studio Handoff

## Purpose

This companion skill orchestrates the succession-management build experience. The existing `aistudio` skill performs all Oracle AI Studio artifact operations, including discovery, inspection, creation, modification, validation, CLI execution, local file writes, server fetch, save, and publish.

Do not invent AI Studio commands, file paths, schema fields, widget types, action payloads, business objects, tools, agents, workflow nodes, or summary-section implementation details. If implementation details are required, hand off to `aistudio`.

## Local-first rule

For every discovery or reference lookup, search the local workspace or local AI Studio project first. Search the environment only if no related local artifact is found, or if the user explicitly asks to compare with environment artifacts.

Environment lookup is read-only. Do not fetch over local files, save, publish, force refresh, overwrite, or otherwise change local or server artifacts as part of discovery.

If `aistudio` requires explicit confirmation before environment or server lookup, pause and ask for confirmation before that lookup.

## Handoff contract

Every AI Studio operation follows this pattern:

1. Summarize the intended operation in user-facing language.
2. Confirm whether the operation is discovery, inspection, creation, modification, validation, server fetch, server save, or publish.
3. If the operation creates or modifies files, obtain explicit confirmation first.
4. Hand off the operation to the `aistudio` skill.
5. Let `aistudio` use its bundled CLI and references from the AI Studio project root.
6. When control returns, summarize results in succession-management language.
7. Present choices and wait for the next user decision.

Keep return summaries medium length. Include only the result details needed for the next decision. Offer `Elaborate` before `Stop` when there is more detail available.

## Rules inherited from `aistudio`

Respect these `aistudio` rules during handoff:

- Classify the requested artifact before selecting references or commands.
- Use `aistudio` for app, workflow, business object, tool, agent, connector, approval, policy, document schema, and function operations.
- Keep AI Studio CLI execution under `aistudio` control.
- Do not invent bare commands or assume global CLI installation.
- Resolve package layout before creating artifacts.
- Do not run project initialization unless the user explicitly requests blank-project initialization.
- Keep generated artifacts local unless the user explicitly asks for server save, publish, fetch, pull, load, or refresh.
- Use local workspace discovery before environment discovery.
- Use server fetch only after explicit user request; if local and server state differ, stop before force behavior.
- For app work, use app intake and app best-practice references.
- For app-backed workflows, respect app-stage routing and app message-hint behavior.
- Confirm first-load panel behavior for app experiences.
- Validate artifacts after creation or material edits when validation commands are available.
- Treat samples as examples only; do not copy sample IDs, business objects, prompts, or wiring.

## Handoff fields

When handing off to `aistudio`, include these fields in prose or structured form:

- Operation type
- Artifact category
- Current selected scope
- Parent workspace decision
- Person-level drill-down decision
- Summary-section status or summary-section task
- Panel or workflow being handled
- Canonical discovery targets from the domain reference
- Discovery source order: local workspace first, environment fallback only if no related local artifact is found
- Whether technical view is requested
- Existing artifacts that must remain read/reuse only
- Current-flow artifacts that may be modified
- `SP_` prefix requirement for new succession-management artifact codes where applicable
- Basic MVP actions being planned: expand, row selection, drill-down, and follow-up questions where supported
- Optional successor suggestion status
- Communication status
- Additional workspace status
- Side-effect status for create-succession or other mutating actions

## Discovery handoff

For workflow discovery, ask `aistudio` to use canonical artifact names and workflow codes from the domain reference. Request local workspace discovery first. If no related local workflow artifacts are found, ask `aistudio` to search the environment as a read-only fallback. Request names, discovered source, discovered status, and short descriptions. Do not ask `aistudio` to infer fit or gaps for existing artifacts.

For app/workspace discovery, ask `aistudio` to discover canonical workspace names in the local workspace first. If no related local app/workspace artifacts are found, ask `aistudio` to search the environment as a read-only fallback. Existing apps or workspaces may be used as references or dependencies only, not modified.

For app summary-section pattern discovery, ask `aistudio` to inspect related existing apps locally first. The purpose is to learn how the app summary section is populated. If no related local app summary reference is found, ask `aistudio` to inspect environment apps as a read-only fallback. Use discovered apps as references only. Do not modify existing apps.

If summary discovery does not reveal a usable pattern, ask `aistudio` to apply the MVP fallback only to the newly created/current-flow app: set `include in summary` on the three parent MVP workflow panels only:

- Succession Overview
- Risk of Loss
- Impact of Loss

Do not set `include in summary` by fallback for person-level drill-down panels.

For new workflow creation, ask `aistudio` to discover relevant business objects first, using the same local-first discovery order. The companion skill should show business objects in user-facing language unless technical view is requested.

For any other artifact discovery, including tools, actions, agents, panels, supporting workflows, or business objects, apply the same rule: local workspace first, environment fallback only when no related local artifact is found or when the user explicitly asks for environment comparison.

## Creation or modification handoff

Before creation or modification, confirm:

- the target is a new/current-flow artifact or a new file to be created
- existing discovered artifacts are not modified
- `SP_` prefix is applied where applicable
- app scope and panel/workflow mapping are approved
- app summary-section setup is approved for MVP
- basic MVP actions are included: expand, row selection, drill-down, and follow-up questions where supported
- side-effecting behavior is included only with explicit opt-in
- communication is included only with explicit selection and confirmed support
- additional workspace creation is included only with explicit selection

Then hand off to `aistudio` for the actual operation.

## App summary-section handoff examples

Use neutral prose rather than command guesses. Example handoff intent:

```text
Operation type: app summary-section discovery and setup
Scope: current succession-management MVP app
Discovery order: inspect related local apps first; if none are found, inspect environment apps read-only
Protection: do not modify existing apps; use them as references only
Fallback: if no summary pattern is discovered, set include in summary only on the Succession Overview, Risk of Loss, and Impact of Loss workflow panels for the current app
Do not include person-level drill-down panels in the parent app summary by fallback
```

Do not expose this technical handoff to the user unless technical view is requested. In normal conversation, summarize it as: `The summary section will be populated from existing app patterns where possible, with a safe MVP fallback if no pattern is found.`

## Return-control summary

After `aistudio` completes an operation, summarize only what is supported by the returned result. Do not invent success, validation status, artifacts, fields, or changes. If `aistudio` reports a failure or ambiguity, present it plainly and offer next choices.

After MVP build and validation, return control to this skill and continue with improvement choices instead of stopping.
