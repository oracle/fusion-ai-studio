# Interactive Workflow

## Top-level principles

Guide the user through an app-to-panel-to-workflow build process. Keep the same functional flow as the existing skill; this reference only controls response style, summary-section handling, post-MVP continuation, and decision sequencing.

Core sequence:

1. Functional orientation.
2. Scope confirmation.
3. Local-first workflow discovery, with environment fallback only when no related local artifact is found.
4. Workflow-to-panel mapping.
5. Reuse or create decision for each selected workflow or panel group.
6. App, workspace, summary-section, and panel planning.
7. App action planning.
8. Pre-build checkpoint.
9. Handoff to `aistudio` for confirmed creation or permitted modification.
10. Validation through `aistudio`.
11. Post-MVP improvement choices.
12. AI Studio build brief.

Pause after each material decision. Present choices and wait for the user's selection before proceeding.

## Response length and choice style

Use medium-length guided responses by default. Do not make responses terse, but do not expand into long tutorials unless the user asks. Avoid unnecessary recaps. Summarize only when a summary helps the user regain context, when returning from `aistudio`, or when validating a stage.

When there is substantial extra information available, keep the main response focused and include `Elaborate` as a choice before `Stop`. Avoid forced brief/detail prompt patterns.

Choice menus must include exactly one bold option containing `Recommended`. Include `Elaborate` before `Stop` only when there is meaningful additional explanation available.

## Functional orientation

Start with a guided, beginner-friendly welcome orientation. Do not start with a terse list of workspace or panel names. Explain the business purpose first, then the recommended build path.

The opening response should help the user understand that a succession-management app can help managers and HR users:

- see readiness and succession coverage at a glance
- identify direct reports or roles that may need attention
- review risk of loss and impact of loss before acting
- use an existing app summary section to highlight immediate planning concerns
- expand panels, select employees, and drill into employee-level details
- ask follow-up questions about displayed succession, risk, impact, and compensation information where supported
- optionally request successor suggestions and candidate review
- optionally add communication or another workspace
- optionally create succession records only after explicit approval

Describe the MVP and full app separately:

- **MVP plus person-level drill-down**: recommended first build. It should include the parent app summary section, core succession coverage, risk of loss, impact of loss, expand/row-selection/drill-down actions, and employee-level drill-downs for succession, risk, impact, and compensation history. Present this as the safest first step because it creates a useful app without adding every enhancement or side effect.
- **Full app**: expanded build. It can add decision-support areas such as top performers, talent needing assistance, compensation summary, successor suggestion, candidate review, communication, additional workspace, and opt-in succession creation. Present this as a later expansion path unless the user chooses it upfront.

Explain the recommended flow in business terms, not technical artifact terms:

1. Start with the MVP and person-level drill-down scope.
2. Discover what already exists locally.
3. Search the environment only if no related local artifact is found.
4. Reuse existing workflows where the user chooses to reuse them.
5. Create only missing new app artifacts after explicit confirmation.
6. Validate the new app and offer improvements after MVP completion.

Do not mention actual workflow names, workflow codes, artifact filenames, or internal identifiers in the opening response unless the user asks for technical view.

Do not ask detailed technical questions immediately. Ask targeted questions only when the answer affects scope, workflow selection, file creation, summary setup, side effects, launch context, validation, or implementation handoff.

## Scope handling

Default scope:

- Succession Readiness Workspace
- Person Succession Readiness Workspace
- Existing app summary section populated for MVP
- Succession Overview
- Risk of Loss
- Impact of Loss
- Succession Information
- Risk of Loss Drill-Down
- Impact of Loss Drill-Down
- Compensation History Drill-Down

Offer optional expansion to complete-app panels after the default scope is understood or after MVP completion. Treat Top Performers, Talent Needing Assistance, and Compensation Summary as optional complete-app additions.

Treat successor suggestion as optional. Treat confirm-and-create succession as explicit opt-in. Treat communication and additional workspace creation as post-MVP enhancement options unless the user explicitly asks for them earlier.

## Workflow discovery

Workflow discovery is the first AI Studio operation. Use `aistudio` to discover canonical workflow targets from the domain reference. Discovery must be local-first: search the local workspace for related artifacts before searching the environment. Search the environment only when no related local artifact is found, or when the user explicitly asks to compare local results with environment artifacts.
Provide a choice to user to search for workflows in the environment as well even if local workflows are found.

Include canonical names and technical workflow codes in the handoff to improve discoverability, but hide codes in the normal user-facing summary unless technical view is requested.

Do not evaluate or invent fit, gap, confidence, suitability, or missing capabilities for existing artifacts. The mapping must show only factual discovery state, names, short descriptions, and user decisions.

When related local artifacts are found, summarize local results and do not search the environment by default. When no related local artifacts are found, proceed to environment discovery through `aistudio` as the fallback for that same discovery goal. If `aistudio` requires explicit confirmation before environment lookup, pause and ask for it.

Allowed discovery statuses:

- Found locally
- Found in environment
- Found
- Not found
- Multiple candidates found
- Description unavailable from discovery
- Needs user decision
- Selected for reuse
- New workflow requested

## Workflow-to-panel mapping

Map panels and drill-down experiences to discovered workflows using factual language only. Use these normal-view columns:

- Panel or experience
- Canonical workflow target
- Discovered workflow
- Short description
- User decision

Do not include fit, gap, score, confidence, suitability, or recommendation columns for existing artifacts.

When descriptions are available from the domain reference, use them. When descriptions are returned by `aistudio`, use those. When neither source has a description, state that the description is unavailable from discovery.

## Workflow reuse shortcut

When a workflow is selected for reuse:

- reuse it as a dependency for the new app
- summarize what it does in business language
- do not show technical codes unless technical view is requested
- do not inspect granular workflow internals by default
- skip separate business-object, boundary, agent, tool, workflow-internal action, and action-configuration decisions
- proceed to app, workspace, summary-section, panel, and app action planning

For multiple panels, the user may reuse different discovered workflows for different panels. If all selected default panels and drill-down experiences have workflows selected for reuse, proceed directly to app/workspace planning.

## New workflow path

Use this path only when a canonical workflow is not found, the user rejects reuse, a selected panel needs a new workflow, or the user explicitly asks to create a new workflow. All discovery inside this path must still be local-first, with environment lookup used only when no related local artifact is found or when the user explicitly asks for environment comparison.

Before any new workflow file is created:

1. Use `aistudio` to discover relevant business objects and supporting capabilities.
2. Summarize discovered business objects in user-facing language.
3. Ask the user to choose the boundary for the new workflow.
4. Present the planned creation operation.
5. Require explicit user confirmation before file creation.
6. Hand off creation to `aistudio`.
7. Validate the new workflow through `aistudio`.
8. Return to panel mapping.

Do not invent business objects, tools, actions, schemas, workflow nodes, or boundaries. Use only discovery results, domain reference content, and `aistudio` conventions.

## App and workspace planning

Plan the app after workflow decisions are clear for the selected scope. Treat canonical workspace names as discovery targets first, not automatic creation instructions.

If the user chooses to create a new app or workspace, label it as a current-flow artifact. Current-flow artifacts may be modified later in the same guided build. Existing discovered apps and workspaces may be inspected or used as references only.

Before creating or modifying any app/workspace file, present the operation and require explicit confirmation.

## Summary-section planning

MVP must include the existing app summary section. Do not create a separate Summary panel by default.

Summary planning sequence:

1. Ask `aistudio` to inspect related existing apps in the local workspace for summary-section patterns.
2. If none are found locally, ask `aistudio` to inspect the environment as a read-only fallback.
3. Use discovered summary patterns as references only. Do not modify existing apps.
4. If discovery does not show a usable summary-population mechanism, use the fallback: set `include in summary` only on the three parent MVP workflow panels.
5. Confirm that person-level drill-down panels are not included in the parent summary by fallback.
6. Apply the summary setup only to the newly created/current-flow app through `aistudio` after confirmation.

MVP fallback parent panels:

- Succession Overview
- Risk of Loss
- Impact of Loss

## Panel planning

Plan panels after app/workspace decisions and workflow mapping. Panels should be powered by selected reused workflows or newly created workflows. Use the domain reference for panel purpose and action expectations.

MVP panel planning must include basic app interactions: expand, select employee row, drill down to person-level details, and ask follow-up questions where selected workflows support query behavior.

When a reused workflow powers a panel, do not inspect or expose its internals unless technical view is requested.

When a new workflow powers a panel, rely on `aistudio` for the workflow build and validation.

## App action planning

Separate panel interactions, app actions, workflow-backed query behavior, communication, additional workspace creation, and side-effecting actions.

Default MVP actions include expansion, row selection, drill-down navigation, and follow-up questions about displayed data where supported by selected workflows. Do not invent action payloads or widget behavior.

Successor suggestion is optional and should use canonical workflow discovery for Potential Succession Candidates when requested.

Confirm-and-create succession is side-effecting. Include it only after explicit opt-in and confirmed `aistudio` support.

Communication is optional. Include it only after explicit user selection and confirmed `aistudio` support.

Additional workspace creation is optional. Offer it after MVP completion or when the user explicitly asks.

## Pre-build checkpoint

Before app creation or material modification, run a short domain-specific checkpoint. First show a summary.
Then Confirm only if the context includes:
- selected scope (include short parent and drill down decision)
- workflow selected or new workflow requested for each panel
- first-load behavior for panels and summary
- basic MVP interactions: expand, row selection, drill-down, and follow-up questions where supported
- optional successor suggestion status
- communication status
- side-effecting create-succession status
- additional workspace status
- launch context
- validation scenario
- file creation or modification target

Intelligently decide what all information to show to confirm. Do not show any information for things that were not included/required in context. 
Example: If MVP is being built then don't confirm communications, side-effect, etc and don't show them as a item in the checklist. 

Do not create or modify files in the same response that first presents this checkpoint.

## Validation

Use `aistudio` for artifact validation after creation or permitted modification. Then summarize validation in user-facing terms and record any issues in the build brief. Validation should also confirm that the MVP app summary section is populated, basic drill-down actions are present where supported, and post-MVP continuation choices are offered after the MVP is built.

## Post-MVP continuation

After MVP build and validation, do not stop with only a completion summary. State that the MVP foundation is ready, then offer improvement choices. Suggested choices:

- Add successor suggestion and candidate review
- Add the opt-in create-succession action
- Add communication support
- Add complete-app panels such as Top Performers, Talent Needing Assistance, or Compensation Summary
- Create and add another workspace
- Improve or review the app summary section
- Validate the MVP again
- Show technical view
- Elaborate, if there is useful extra explanation
- Stop

Exactly one choice must be marked as `Recommended`. Usually recommend successor suggestion and candidate review after MVP unless validation issues remain; if validation issues exist, recommend fixing validation first.

## AI Studio build brief

End with an AI Studio build brief containing:

1. App purpose.
2. Selected scope.
3. Parent workspace decision.
4. Person-level drill-down workspace decision.
5. Summary-section status and source: discovered local pattern, discovered environment pattern, or fallback `include in summary` setup.
6. Panel list.
7. Basic MVP actions included.
8. Workflow selected or created for each panel.
9. Existing artifacts reused as dependencies only.
10. New artifacts created in the current flow.
11. New artifacts that may be modified.
12. Existing artifacts that must not be modified.
13. Optional enhancements included or omitted.
14. Side-effecting actions included or omitted.
15. Validation result.
16. Remaining unsupported or undecided items.
17. Next `aistudio` handoff instruction.

Include technical codes only when technical view is requested or implementation handoff requires them.
