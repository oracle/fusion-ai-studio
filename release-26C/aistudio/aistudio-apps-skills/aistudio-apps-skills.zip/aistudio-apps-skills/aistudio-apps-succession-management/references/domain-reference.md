# Succession Management Domain Reference

## Purpose

The Succession Management Agentic app helps managers and HR administrators review workforce readiness with AI-assisted summaries, panels, actions, and drill-downs. It brings together succession coverage, talent strength, retention risk, role criticality, and compensation context so users can understand where attention or action may be needed.

Managers use the app to assess readiness across direct teams. HR administrators use the app to support broader talent planning, identify planning concerns, and guide consistent succession-management practices.

## Beginner-facing orientation

Use this domain framing in the first response and in learner-friendly explanations. Do not start by naming workflows or codes.

A good succession-management app should help the user move from a broad team view to a specific employee review. The user should be able to open a manager-level snapshot, see where succession coverage, retention risk, or business impact needs attention, expand panels, select a direct report, drill down into employee-level details, and ask follow-up questions about the displayed information. Optional enhancements can add successor suggestions, candidate review, communication, additional workspaces, and explicit opt-in succession creation.

Recommended first build: MVP plus person-level drill-down. Describe it as a practical first version with enough value for managers: it includes the app summary section, succession coverage, risk of loss, impact of loss, basic expand/row-selection/drill-down actions, and employee-level detail views without adding every advanced panel or side-effecting action at the start.

Full app: an expanded version that can add top performers, talent needing assistance, compensation summary, successor suggestions, candidate review, communication, additional workspaces, and opt-in succession creation. Present the full app as a natural expansion after the MVP is working, unless the user explicitly wants the full build first.

## Default scope

Default to MVP plus person-level drill-down.

### Parent workspace

- Canonical name: Succession Readiness Workspace
- Purpose: parent manager-facing workspace with succession-management summary and panels.

### Person-level drill-down workspace

- Canonical name: Person Succession Readiness Workspace
- Purpose: employee-level drill-down workspace with succession, risk, impact, and compensation views.

## App summary section

The MVP must populate the existing app summary section. Source documentation uses `Summary Panel` terminology, but this companion skill should treat that content as guidance for the app's existing summary section, not as a separate new panel by default.

The summary section should provide a concise manager-level snapshot of succession readiness across direct reports. It should help identify direct reports with no succession plan and direct reports who have a plan but no ready-now successor, then present action-oriented guidance.

Summary setup order:

1. Ask `aistudio` to inspect related existing apps in the local workspace for summary-section population patterns.
2. If no related local reference is found, ask `aistudio` to inspect the environment as a read-only fallback.
3. Use discovered apps only as references. Never modify them.
4. If discovery does not reveal a summary-population pattern, use the MVP fallback: set `include in summary` only on the three parent MVP workflow panels.

MVP fallback summary contributors:

- Succession Overview
- Risk of Loss
- Impact of Loss

Do not include person-level drill-down panels in the parent app summary by fallback.

## MVP panels

| Panel | Primary goal | Basic actions expected in MVP |
| --- | --- | --- |
| Succession Overview | Review succession plan availability, successor readiness, and bench-strength gaps across direct reports. | Expand panel, select a direct report, drill down to employee-level details, ask follow-up questions where supported. |
| Risk of Loss | Identify direct reports with elevated retention risk who may require manager attention. | View risk indicators, select a direct report, drill down to risk details, ask follow-up questions where supported. |
| Impact of Loss | Highlight employees whose departure could create meaningful business impact. | View impact indicators, select a direct report, drill down to impact details, ask follow-up questions where supported. |

## Default person-level drill-down experiences

| Drill-down experience | Primary goal |
| --- | --- |
| Succession Information | Review person-level succession, performance, risk, impact, and compensation attributes in one drill-down view. |
| Risk of Loss Drill-Down | Review an individual employee's current risk rating and short explanatory summary. |
| Impact of Loss Drill-Down | Review an individual employee's impact rating and short explanatory summary. |
| Compensation History Drill-Down | Review an employee's annual salary trend over time. |

## Optional complete-app panels

Treat these as optional expansions beyond the default scope:

| Panel | Primary goal |
| --- | --- |
| Top Performers | Surface higher-performing employees to support recognition, growth, and succession planning. |
| Talent Needing Assistance | Identify employees with lower performance ratings who may need coaching, support, or development planning. |
| Compensation Summary | Review compensation details for direct reports to support balanced talent and pay decisions. |

## Optional enhancements and side effects

Successor suggestion and candidate review are optional post-MVP enhancements. If requested, use the canonical Potential Succession Candidates workflow as a discovery target.

Candidate review is optional and should be introduced only after successor suggestion is selected.

Confirm-and-create succession is an opt-in side-effecting action. Do not include it in the default MVP. Before planning or creating this action, require explicit user confirmation and confirmed `aistudio` support.

Communication is optional and should be introduced after MVP build or when explicitly requested. Treat send-message, email, notification, or similar behavior as side-effecting unless `aistudio` confirms otherwise.

Additional workspace creation is optional and should be offered after the MVP foundation is complete or when the user explicitly asks for another workspace.

Server save, server fetch, and publish operations are out of scope unless the user explicitly requests them and `aistudio` confirms the supported path.

## Functional flow

Use this functional sequence as a domain guide, not as an automatic creation script:

1. User opens the workspace and sees a manager-level summary plus core panels.
2. User expands a panel to inspect direct-report information.
3. User selects and reviews an employee.
4. User drills down into person-level succession, risk, impact, and compensation history.
5. User may optionally ask for successor suggestions.
6. User may optionally review suggested candidates.
7. User may explicitly opt in to confirm and create succession.
8. User may optionally add communication or another workspace.

## Panel behavior notes

### Succession Overview

The Succession Overview panel helps managers identify which direct reports have succession coverage, which employees have no succession plan, and which covered roles have no ready-now successor. It is the main triage panel for successor readiness and follow-up action. Candidate review can combine successor candidate data with succession, salary, and talent rating context when those fields are available.

### Risk of Loss

The Risk of Loss panel shows employee risk levels and risk scores in a concise view and supports employee drill-down through row actions.

### Impact of Loss

The Impact of Loss panel shows which direct reports are most critical from a continuity perspective and helps managers understand where a departure could have higher operational or business impact.

### Top Performers

The Top Performers panel surfaces higher-performing direct reports so managers can consider growth, retention, and succession opportunities.

### Talent Needing Assistance

The Talent Needing Assistance panel gives visibility into employees who may need coaching, support, training, or performance follow-up.

### Compensation Summary

The Compensation Summary panel provides current compensation and pay-positioning context for direct reports.

### Succession Information drill-down

The Succession Information drill-down gives a consolidated employee-level view combining succession, compensation, performance, risk, and impact context.

### Risk of Loss drill-down

The Risk of Loss drill-down gives a focused explanation of the selected employee's current attrition-risk assessment.

### Impact of Loss drill-down

The Impact of Loss drill-down gives a focused explanation of the selected employee's business criticality and continuity impact.

### Compensation History drill-down

The Compensation History drill-down shows annual salary progression over time for the selected employee.

## Canonical artifact discovery targets

Use these names as canonical discovery targets. Search local workspace first. Search the environment only if no related local artifact is found or the user explicitly asks to compare environment artifacts. Do not treat these names as automatic creation instructions.

| Artifact | Type | Role |
| --- | --- | --- |
| Succession Readiness Workspace | App | Parent workspace with manager-facing succession-management summary and panels. |
| Person Succession Readiness Workspace | App | Person-level drill-down workspace with succession, risk, impact, and compensation panels. |
| Succession Overview Advisor | Workflow | Main parent-panel workflow for succession coverage, expanded views, employee detail, successor candidate suggestions, and successor creation. |
| Risk Of Loss Advisor | Workflow | Parent-panel workflow for the Risk of Loss panel. |
| Impact of Loss Advisor | Workflow | Parent-panel workflow for the Impact of Loss panel. |
| Succession Analysis | Workflow | Person-level drill-down workflow for consolidated succession, compensation, performance, risk, and impact details. |
| Risk of Loss Analysis | Workflow | Person-level drill-down workflow for selected employee risk-of-loss explanation. |
| Impact of Loss Analysis | Workflow | Person-level drill-down workflow for selected employee impact-of-loss explanation. |
| Compensation Analysis | Workflow | Person-level drill-down workflow for selected employee compensation-history line chart. |
| Potential Succession Candidates | Workflow | Supporting workflow that ranks possible successor candidates for a selected employee using profile, skills, competency, and manager-context data. |
| Succession Overview Agent Team | Workflow | Shared workflow used by parent-panel advisors to return succession details, risk of loss, and impact of loss records for direct reports. |
| Top Talent Advisor | Workflow | Parent-panel workflow for the Top Performers panel. |
| Bottom Talent Advisor | Workflow | Parent-panel workflow for the Talent Needing Assistance panel. |
| Compensation Advisor | Workflow | Parent-panel workflow for the Compensation Summary panel. |
| Fetch Performers | Workflow | Supporting workflow that filters direct reports into top performer and talent-needing-assistance lists based on current performance ratings. |
| Fetch Compensation Details | Workflow | Supporting workflow that retrieves current compensation details for direct reports and handles compensation-related follow-up questions. |

## Technical artifact codes

Expose these only in technical view or implementation handoff:

- Parent app code from source documentation: XX_SUCCESSION_READINESS_WORKSPACE
- Person drill-down app code from source documentation: XX_PERSON_SUCCESSION_READINESS_WORKSPACE
- xx_bottom_talent_advisor.wf
- xx_potential_succession_candidates.wf
- xx_compensation_advisor.wf
- xx_risk_of_loss_advisor.wf
- xx_compensation_analysis.wf
- xx_risk_of_loss_analysis.wf
- xx_fetch_compensation_details.wf
- xx_succession_analysis.wf
- xx_fetch_performers.wf
- xx_succession_overview_advisor.wf
- xx_impact_of_loss_advisor.wf
- xx_succession_overview_agent_team.wf
- xx_impact_of_loss_analysis.wf
- xx_top_talent_advisor.wf
